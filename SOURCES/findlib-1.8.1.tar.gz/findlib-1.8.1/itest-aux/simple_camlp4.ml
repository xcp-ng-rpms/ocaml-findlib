(* This is revised syntax: *)

value x = 1;

print_endline "OK";
